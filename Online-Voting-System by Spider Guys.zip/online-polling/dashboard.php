<?php
include 'db.php';
session_start();
if(!isset($_SESSION['userdata'])){
    header("location: ../online-voting/index.php");

}
$userdata= $_SESSION['userdata']; ?>
<?php

$query ="SELECT * FROM statements";
$total_questions = mysqli_num_rows(mysqli_query($connect,$query));

?>

<!DOCTYPE html>
<html>
    <head></head>
<body style="text-align:center;  background-color: rgb(255, 155, 109);">


<div>
    <div><h1>Welcome User</h1>
<hr>
</div>


    <div id="Profile" style="float:left; font-size:20px">
   <b style="margin-left:580px">First Name:</b> <?php echo $userdata['firstName']?><br>
        <b style="margin-left:580px">Last Name: </b><?php echo $userdata['lastName']?><br>
        <b style="margin-left:580px">CNIC: </b><?php echo $userdata['cnic']?><br>
  
    </div>
   <br>
    <br>
    <br>
    <br>

    <div>
        <a href="voting.php?n=1"> START VOTING</a>
<a href="add_poll.php"> CREATE YOU OWN POLL</a></div>
</div>

<div style="margin-top:50px">
<button>Back</button>
<button>LogOut</button>
</div>
</body>
</html>