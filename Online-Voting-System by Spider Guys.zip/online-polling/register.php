<!DOCTYPE html>
<html>
    <head></head>
<body style="text-align:center;  background-color: rgb(255, 155, 109);">
<center>
<h1>Welcome</h1>
<hr>
<h3>User Registration</h3>
<form action="register_server.php" method="POST">
  <label for="fname">First name:</label>
  <input type="text" id="fname" name="fname" style="width: 25%;padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;"><br><br>
  <label for="lname">Last name:</label>
  <input type="text" id="lname" name="lname" style="width: 25%;padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;"><br><br>
  <label for="cn">CNIC:</label>
  <input type="number" id="cnic" name="cnic" style="width: 25%;padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;"><br><br>
  <label for="lname">Password:</label>
  <input type="password" id="password" name="password" style="width: 25%;padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;"><br><br>
  <input type="submit" value="Submit" style="width: 10%;background-color: #4CAF50;color: white;padding: 14px 20px;margin: 8px 0;border: none;border-radius: 4px;cursor: pointer;">
</form><br><br>
<span>Already a User?</span>
<a href="login.php">Login</a><br><br>


<center>
</body>
</html>