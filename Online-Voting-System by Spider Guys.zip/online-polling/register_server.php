<?php

include("db.php");

$fname= $_POST['fname'];
$lname= $_POST['lname'];
$cnic=$_POST['cnic'];
$password=$_POST['password'];


$insert= mysqli_query($connect, "INSERT INTO user (firstName, lastName, cnic, password) VALUES('$fname','$lname','$cnic','$password')");
if($insert){
    echo '<script>
        alert("Registration Successful");
        window.location="../online-polling/login.php";
    </script>';
}
else{
    '<script>
        alert("Error");
        window.location="../";
    </script>';

}
?>