<?php
include 'db.php';
session_start();
$gvotes=$_POST['gvotes'];
$total_votes= (int)$gvotes+(int)1;
$number= $_POST['number'];
$selected=$_POST['option'];
$n=(int)$number+(int)1;



$query =mysqli_query($connect, "UPDATE * FROM options SET votes='$total_votes' WHERE statement_no =$number AND diff_option=$selected");
echo '
    <script>
        window.location="../online-polling/voting.php?n"';




?>