<!DOCTYPE html>
<html>
    <head></head>
<body style="text-align:center">
<center>
<h1>Welcome</h1>
<hr>
<h3>POLLS</h3>

<div>Statement <?php echo $number;?> of <?php echo $total_questions; ?><div>
    <div>
        <p>
        <?php echo $statements['statement_text'];?>
        </p>
        <form action="#">

<ul name="options">

<?php while($row=mysqli_fetch_assoc($options)){ ?>
    <li><input type="radio" name="option" value="<?php echo $row['id'];?>"/><?php echo $row['diff_option']; ?></li><br><br>


</ul> 
 
  <input type="submit" value="Submit">
</form>
    </div>
</body>
</html>