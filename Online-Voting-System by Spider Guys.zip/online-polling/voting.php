<?php 
include 'db.php';
session_start();

$number = $_GET['n'];

$query="SELECT * FROM statements WHERE statement_no=$number";

$result= mysqli_query($connect,$query);
$statements= mysqli_fetch_assoc($result);

$query ="SELECT * FROM options WHERE statement_no =$number";
$options = mysqli_query($connect, $query);

$query = "SELECT * FROM statements";
$total_questions = mysqli_num_rows(mysqli_query($connect,$query));

?>

<html>
    <head></head>
    <body  style="text-align:center;  background-color: rgb(255, 155, 109);font-size:25px">
<h3>POLLS</h3>
<b><div>Statement <?php echo $number;?> of <?php echo $total_questions; ?><div>
<p>
        <?php echo $statements['statement_text'];?>
        </p></b>


        <form action="poll_form.php" method="POST">

<ul style="list-style:none; ">

<?php while($row=mysqli_fetch_assoc($options)){ ?>
    <input type="hidden" name="gvotes" value="<?php echo $row['id']; ?> ">
    <li><input type="radio" name="option" value="<?php echo $row['id']; ?>"><?php echo $row['diff_option']; ?> <span style="margin-left: 30px;">Votes:<?php echo $row['votes']; ?></span></li>
    <input type="hidden" name="gid" value="<?php echo $row['id']; ?> ">
    <?php } ?>
    
</ul> 
<input type="hidden" name="number" value="<?php echo $number; ?> ">
 
  <input type="submit" value="Submit">
</form>
<h4>Poll Results<h4>
    <div id="poll_result"></div>
</body>
</html>
