<!DOCTYPE html>
<html>
    <head></head>
 
<body style="text-align:center;  background-color: rgb(255, 155, 109);">
<center>
<h1>Welcome</h1>
<hr>
<h2>User Login</h2></center>
<form action="login_server.php" method="POST">

<label for="number">CNIC:</label>
  <input type="number" id="form-data" name="cnic" style="width: 25%;padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;"><br><br>
  <label >Password:</label>
  <input type="password" id="form-data" name="password" style="width: 25%;padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;"> <br><br>

 
  <input type="submit" value="Submit"  style="width: 10%;background-color: #4CAF50;color: white;padding: 14px 20px;margin: 8px 0;border: none;border-radius: 4px;cursor: pointer;"/>
</form><br><br>
<a href="register.php">Register Here</a><br><br>
<a href="index.php">Anonymous Poll</a>


</body>
</html>