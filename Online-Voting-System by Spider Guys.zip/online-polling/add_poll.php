<?php 
session_start();
include 'db.php';
if(isset($_POST['submit']))
{
    $statement_no=$_POST['statement_no'];
    $statement=$_POST['statement'];
    
    $choice = array();
    $choice[1]=$_POST['choice1'];
    $choice[2]=$_POST['choice2'];
    $choice[3]=$_POST['choice3'];
    $choice[4]=$_POST['choice4'];
    $choice[5]=$_POST['choice5'];

    $query="INSERT INTO statements (";
    $query .= "statement_no, statement_text )";
    $query .= "VALUES (";
    $query .=" '{$statement_no}', '{$statement}'";
    $query .= ")";

    $result =mysqli_query($connect,$query);

    if($result)
    {
        foreach($choice as $option => $value)
        {
            if($value != "")
            {
                $query = "INSERT INTO options (";
                $query .= "statement_no, diff_option, votes)";
                $query .=" VALUES (";
                $query .= "'{$statement_no}','{$value}', {0})";

                $insert_row = mysqli_query($connect,$query);

                if($insert_row)
                {
                    continue;
                }
                else
                {
                    die("2nd Q was not executed");
                }
            }
        }
$message ="Added Successfully";

    }

} 

$query ="SELECT * FROM statements";
$statements = mysqli_query($connect,$query);
$total =mysqli_num_rows($statements);
$next = $total+1;






?>


<!DOCTYPE html>
<html>
    <head></head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<body >
<center>
<h1>Welcome</h1>
<?php if(isset($message)){
    echo "<h4>". $message ."</h4>";
    }?>
<hr>
<form action="add_poll.php" method="POST">
<label>Statement Number</label>
<input type="number" id="statement" name="statement_no" value="<?php echo $next;?>"><br><br>
<label>Statement</label>
<input type="text" id="statement" name="statement"><br><br>
<p>
<label>Choice 1:</label>
<input type="text" name="choice1"><br><br>
</p>
<p>
<label>Choice 2:</label>
<input type="text" name="choice2"><br><br>
</p>
<p>
<label>Choice 3:</label>
<input type="text" name="choice3"><br><br>
</p>
<p>
<label>Choice 4:</label>
<input type="text" name="choice4"><br><br>
</p>
<p>
<label>Choice 5:</label>
<input type="text" name="choice5"><br><br>
</p>
 
  <input type="submit" name="submit"value="Submit">
</form>
<a href="dashboard.php">Back</a>

<center>
</body>
</html>