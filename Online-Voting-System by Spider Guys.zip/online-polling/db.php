<?php

$connect=mysqli_connect("localhost","root","","polling") or die("connection failed");

?>