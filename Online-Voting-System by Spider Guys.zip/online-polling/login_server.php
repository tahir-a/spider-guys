<?php
session_start();
include("db.php");


$cnic= $_POST['cnic'];
$password=$_POST['password'];


$check= mysqli_query($connect, "SELECT * FROM user WHERE cnic='$cnic' AND password='$password' ");


if(mysqli_num_rows($check)>0){
    $userdata= mysqli_fetch_array($check);
    $_SESSION['userdata']=$userdata;


    echo '
    <script>
        window.location="../online-polling/dashboard.php";
    </script>';
}
else{
    echo '
    <script>
        alert("Not Found");
        window.location="../online-polling/index.php";
    </script>';
}
?>